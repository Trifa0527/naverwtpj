package com.kgitbank.webtoon.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.kgitbank.webtoon.model.InitialDTO;
import com.kgitbank.webtoon.model.WebtoonDTO;

@Repository
public class WebtoonDAO {

	@Inject
	private SqlSession sqlSession;

	public List<WebtoonDTO> getWtByGenre(String genre) throws Exception {
		System.out.println("getWtByGenre DAO : " + genre);
		return sqlSession.selectList(
				"org.spring.mapper.WebtoonMapper.selectByGenre", genre);
				
	}
	
	public List<WebtoonDTO> getWtByArtist(InitialDTO initialDTO) throws Exception {
		return sqlSession.selectList(
				"org.spring.mapper.WebtoonMapper.selectByArtist", initialDTO);
				
	}
	
	public List<WebtoonDTO> getWtByCreation(InitialDTO initialDTO) throws Exception {
		return sqlSession.selectList(
				"org.spring.mapper.WebtoonMapper.selectByCreation", initialDTO);
				
	}
	
	public List<WebtoonDTO> getWtByPeriod(String period) throws Exception {
		return sqlSession.selectList(
				"org.spring.mapper.WebtoonMapper.selectByPeriod", period);
				
	}
	
}
