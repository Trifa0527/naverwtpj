package com.kgitbank.webtoon;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kgitbank.webtoon.model.InitialDTO;
import com.kgitbank.webtoon.model.WebtoonDTO;
import com.kgitbank.webtoon.service.WebtoonService;

@Controller
public class WebtoonController {
	@Autowired
	private WebtoonService webtoonService;
	
	@RequestMapping("/index")
	public String index() {
		System.out.println("index �޼ҵ尡 ����ƽ��ϴ�.");
		return "index";
	}
	
	@RequestMapping("/menubar")
	public String menu() {
		System.out.println("menu �޼ҵ尡 ����ƽ��ϴ�.");
		return "menubar/menubar";
	}
	
	
	@RequestMapping("/genre")
	public String genre(String genre, Model model) throws Exception {
		
		if (genre == null) {
			genre = "episode";
		}
		
		List<WebtoonDTO> webtoonDTOList = webtoonService.getWtByGenre(genre);
		
		if (webtoonDTOList.size() != 0) {
			model.addAttribute("list", webtoonService.getWtByGenre(genre));	
		}
		model.addAttribute("amount", webtoonDTOList.size());
		
		String genreko = null;
		
		if(genre.equals("episode")) {
			genreko = "���Ǽҵ�";
		} else if (genre.equals("omnibus")) {
			genreko = "�ȴϹ���";
		} else if (genre.equals("story")) {
			genreko = "���丮";
		} else if (genre.equals("daily")) {
			genreko = "�ϻ�";
		} else if (genre.equals("comic")) {
			genreko = "����";
		} else if (genre.equals("fantasy")) {
			genreko = "��Ÿ��";
		} else if (genre.equals("action")) {
			genreko = "�׼�";
		} else if (genre.equals("drama")) {
			genreko = "���";
		} else if (genre.equals("pure")) {
			genreko = "����";
		} else if (genre.equals("sensibility")) {
			genreko = "����";
		} else if (genre.equals("thrill")) {
			genreko = "������";
		} else if (genre.equals("historical")) {
			genreko = "�ô��";
		}  else if (genre.equals("sports")) {
			genreko = "������";
		}
		
		model.addAttribute("genre", genreko);
		
		return "genre/genre";
	}
	
	
	@RequestMapping("/artist")
	public String artist(InitialDTO initialDTO, Model model) throws Exception {
		
		if (initialDTO.getInitial() == null) {
			initialDTO.setInitial("��ü");
		}
		
		List<WebtoonDTO> webtoonDTOList = webtoonService.getWtByArtist(initialDTO);
		
		if (webtoonDTOList.size() != 0) {
			model.addAttribute("list", webtoonService.getWtByArtist(initialDTO));	
		}
		
		model.addAttribute("artist", initialDTO.getInitial());
		
		return "artist/artist";
	}
	

	@RequestMapping("/creation")
	public String creation(InitialDTO initialDTO, Model model) throws Exception {
		
		if (initialDTO.getInitial() == null) {
			initialDTO.setInitial("��ü");
		}
		
		List<WebtoonDTO> webtoonDTOList = webtoonService.getWtByCreation(initialDTO);
		
		if (webtoonDTOList.size() != 0) {
			model.addAttribute("list", webtoonService.getWtByCreation(initialDTO));	
		}
		
		model.addAttribute("initial", initialDTO.getInitial());
		
		return "creation/creation";
	}
	
	@RequestMapping("/period")
	public String period(String period, Model model) throws Exception {
		
		if (period == null) {
			period = "2021";
		}
		
		List<WebtoonDTO> webtoonDTOList = webtoonService.getWtByPeriod(period);
		
		if (webtoonDTOList.size() != 0) {
			model.addAttribute("list", webtoonService.getWtByPeriod(period));
		}
		
		model.addAttribute("period", period);
		
		return "period/period";
	}
	
	
}
