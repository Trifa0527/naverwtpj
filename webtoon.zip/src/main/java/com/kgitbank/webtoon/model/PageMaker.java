package com.kgitbank.webtoon.model;

public class PageMaker {

}
