package com.kgitbank.webtoon.model;

public class InitialDTO {
	String initial;

	public String getInitial() {
		return initial;
	}

	public void setInitial(String initial) {
		this.initial = initial;
	}

	@Override
	public String toString() {
		return "InitialDTO [initial=" + initial + "]";
	}
	
	
}
