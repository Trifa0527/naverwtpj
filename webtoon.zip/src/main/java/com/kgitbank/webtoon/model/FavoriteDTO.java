package com.kgitbank.webtoon.model;

public class FavoriteDTO {

	String wbt_member_id;
	int wt_wtid;
	
	public String getWbt_member_id() {
		return wbt_member_id;
	}
	public void setWbt_member_id(String wbt_member_id) {
		this.wbt_member_id = wbt_member_id;
	}
	
	public int getWt_wtid() {
		return wt_wtid;
	}
	public void setWt_wtid(int wt_wtid) {
		this.wt_wtid = wt_wtid;
	}
	
	@Override
	public String toString() {
		return "FavoriteDTO [wbt_member_id=" + wbt_member_id + ", wt_wtid=" + wt_wtid + "]";
	}
	
}
