package com.kgitbank.webtoon;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/mypage")
@Controller
public class MypageController {

	@RequestMapping("/favorite")
	public String favorite(HttpServletRequest req) {
		return "mypage/favorite";
	}
	
	@RequestMapping("/bookmark")
	public String bookmark(HttpServletRequest req) {
		return "mypage/bookmark";
	}
	
	@RequestMapping("/myActivity")
	public String myActivity(HttpServletRequest req) {
		return "mypage/myActivity";
	}
	
	@RequestMapping("/penalty")
	public String penalty(HttpServletRequest req) {
		return "mypage/penalty";
	}

}
