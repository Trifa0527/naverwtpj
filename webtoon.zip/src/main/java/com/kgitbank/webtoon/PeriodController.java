package com.kgitbank.webtoon;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/period")
@Controller
public class PeriodController {

	@RequestMapping("/periodHome")
	public String creation(String period, Model model) {
		System.out.println("period���� period �޼ҵ尡 ����ƽ��ϴ�.");
		
		model.addAttribute("year", period);
		
		return "period/period";
	}
	
	@RequestMapping("/periodList")
	public String creationList(String period, Model model) {
		System.out.println("period���� periodList �޼ҵ尡 ����ƽ��ϴ�.");

		model.addAttribute("year", period);
		
		return "period/periodList";
	}
}
