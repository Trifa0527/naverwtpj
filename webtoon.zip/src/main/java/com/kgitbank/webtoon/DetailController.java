package com.kgitbank.webtoon;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.kgitbank.webtoon.model.FavoriteDTO;
import com.kgitbank.webtoon.model.MemberDTO;
import com.kgitbank.webtoon.service.MemberService;

import dbdao.DBDAO;

@Controller
public class DetailController {
	@Autowired
	private MemberService memberService;
	
	@RequestMapping(value = "/detail", method = RequestMethod.GET)
	public String weekday(@RequestParam("titleId") int id,Model model) {
		try {
			DBDAO dbdao = new DBDAO();
			String title = null;
			String intro = null;
			String artist = null;
			String genre = null;
			int age = -1;
			
			title = dbdao.getTitle(id);
			intro = dbdao.getIntro(id);
			artist = dbdao.getArtist(id);
			genre = dbdao.getGenre(id);
			age = dbdao.getAge(id);
			
			genre = genre.replace("episode", "에피소드");
			genre = genre.replace("omnibus", "옴니버스");
			genre = genre.replace("story", "스토리");
			genre = genre.replace("daily", "일상");
			genre = genre.replace("comic", "개그");
			genre = genre.replace("fantasy", "판타지");
			genre = genre.replace("action", "액션");
			genre = genre.replace("drama", "드라마");
			genre = genre.replace("pure", "순정");
			genre = genre.replace("sensibility", "감성");
			genre = genre.replace("thrill", "스릴러");
			genre = genre.replace("historical", "시대극");
			genre = genre.replace("sports", "스포츠");
			genre = genre.replace("romance", "로맨스");
			
			model.addAttribute("id", id);
			model.addAttribute("title", title);
			model.addAttribute("intro", intro);
			model.addAttribute("artist", artist);
			model.addAttribute("genre", genre);
			model.addAttribute("age", age);
			return "detail";
		}catch (Exception e){
			e.printStackTrace();
		}
		return "detail";
	}
	
	@ResponseBody
	@RequestMapping(value="/addFavorite")
	public String addFavorite(int titleId, 	HttpSession session) throws Exception {
		MemberDTO memberDTO = (MemberDTO) session.getAttribute("login");
		FavoriteDTO favoriteDTO = new FavoriteDTO();
		favoriteDTO.setWt_wtid(titleId);
		favoriteDTO.setWbt_member_id(memberDTO.getId());
		
		memberService.addFavorite(favoriteDTO); 
		
		return "성공";
				
	}
	
	@RequestMapping(value="/delFavorite")
	public String delFavorite(int titleId, 	HttpSession session) throws Exception {
		MemberDTO memberDTO = (MemberDTO) session.getAttribute("login");
		FavoriteDTO favoriteDTO = new FavoriteDTO();
		favoriteDTO.setWt_wtid(titleId);
		favoriteDTO.setWbt_member_id(memberDTO.getId());
		
		memberService.delFavorite(favoriteDTO);
		
		return "redirect:";
		
	}
}
