package com.kgitbank.webtoon.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kgitbank.webtoon.dao.MemberDAO;
import com.kgitbank.webtoon.model.FavoriteDTO;
import com.kgitbank.webtoon.model.MemberDTO;

@Service
public class MemberService {

	@Autowired
	private MemberDAO memberDAO;
	
	public void join(MemberDTO memberDTO) throws Exception {
		memberDAO.insertMember(memberDTO);
	}

	public MemberDTO login(MemberDTO memberDTO) throws Exception {
		return memberDAO.selectMember(memberDTO);
	}
	
	public void addFavorite(FavoriteDTO favoriteDTO) throws Exception {
		memberDAO.addFavorite(favoriteDTO);
	}
	
	public void delFavorite(FavoriteDTO favoriteDTO) throws Exception {
		memberDAO.delFavorite(favoriteDTO);
	}
}
