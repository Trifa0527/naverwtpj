package com.kgitbank.webtoon.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kgitbank.webtoon.dao.WebtoonDAO;
import com.kgitbank.webtoon.model.InitialDTO;
import com.kgitbank.webtoon.model.WebtoonDTO;

@Service
public class WebtoonService {
	@Autowired
	private WebtoonDAO webtoonDAO;
	

	public List<WebtoonDTO> getWtByGenre(String genre) throws Exception {
		
		return webtoonDAO.getWtByGenre(genre);
	}
	
	public List<WebtoonDTO> getWtByArtist(InitialDTO initialDTO) throws Exception {
	
		return webtoonDAO.getWtByArtist(initialDTO);
	}

	public List<WebtoonDTO> getWtByCreation(InitialDTO initialDTO) throws Exception {
		
		return webtoonDAO.getWtByCreation(initialDTO);
	}
	
	public List<WebtoonDTO> getWtByPeriod(String period) throws Exception {
		
		return webtoonDAO.getWtByPeriod(period);
	}
	

}
